# Optional helper functions
